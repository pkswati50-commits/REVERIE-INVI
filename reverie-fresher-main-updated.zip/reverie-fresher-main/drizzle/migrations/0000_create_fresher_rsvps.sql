CREATE TABLE public.fresher_rsvps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL CHECK (char_length(full_name) BETWEEN 2 AND 80),
  usn TEXT NOT NULL UNIQUE CHECK (char_length(usn) BETWEEN 6 AND 15),
  branch TEXT NOT NULL CHECK (char_length(branch) BETWEEN 2 AND 80),
  answers JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT ALL ON public.fresher_rsvps TO service_role;

ALTER TABLE public.fresher_rsvps ENABLE ROW LEVEL SECURITY;
-- No policies on purpose: visitors can never read or list responses (USNs stay private).
-- Writes happen only through the app's server, which validates every field.