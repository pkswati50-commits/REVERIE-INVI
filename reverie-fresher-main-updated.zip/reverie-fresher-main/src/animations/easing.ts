/** Shared motion tokens. Slow, weighty, expensive — never bouncy. */
export const EASE_LUXE = [0.22, 1, 0.36, 1] as const;
export const EASE_SILK = [0.65, 0, 0.35, 1] as const;
export const GSAP_LUXE = "expo.out";
export const GSAP_SILK = "power3.inOut";
export const GSAP_CURTAIN = "expo.inOut";
