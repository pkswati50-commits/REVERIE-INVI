import { forwardRef, useImperativeHandle, useRef } from "react";

export type CurtainsHandle = { root: HTMLDivElement | null; left: HTMLDivElement | null; right: HTMLDivElement | null; seam: HTMLDivElement | null };

/** Golden velvet curtains with fold shading, gold fringe and a seam flare. */
export const Curtains = forwardRef<CurtainsHandle>(function Curtains(_, ref) {
  const root = useRef<HTMLDivElement>(null);
  const left = useRef<HTMLDivElement>(null);
  const right = useRef<HTMLDivElement>(null);
  const seam = useRef<HTMLDivElement>(null);
  useImperativeHandle(ref, () => ({
    get root() { return root.current; },
    get left() { return left.current; },
    get right() { return right.current; },
    get seam() { return seam.current; },
  }));
  const panel = (side: "l" | "r") => (
    <div
      ref={side === "l" ? left : right}
      className={`velvet absolute top-0 h-full w-[51%] ${side === "l" ? "left-0" : "right-0"}`}
      style={{ willChange: "transform" }}
    >
      {/* top valance */}
      <div className="absolute inset-x-0 top-0 h-[9%] velvet" style={{ filter: "brightness(1.15)" }} />
      <div className="fringe absolute inset-x-0 top-[9%] h-5" />
      {/* inner edge shading */}
      <div
        className="absolute inset-y-0 w-10"
        style={{
          [side === "l" ? "right" : "left"]: 0,
          background: `linear-gradient(${side === "l" ? "270deg" : "90deg"}, color-mix(in oklab, var(--gold-light) 40%, transparent), transparent)`,
        }}
      />
      <div className="fringe absolute inset-x-0 bottom-0 h-6 rotate-180" />
    </div>
  );
  return (
    <div ref={root} aria-hidden="true" className="pointer-events-none absolute inset-0 z-40 overflow-hidden opacity-0">
      {panel("l")}
      {panel("r")}
      <div
        ref={seam}
        className="absolute left-1/2 top-0 h-full w-24 -translate-x-1/2 opacity-0"
        style={{ background: "radial-gradient(ellipse 50% 60% at 50% 50%, var(--ivory), color-mix(in oklab, var(--gold-light) 60%, transparent) 30%, transparent 70%)" }}
      />
    </div>
  );
});
