import { forwardRef, useImperativeHandle, useRef } from "react";
import { content } from "@/config/content";

export type EnvelopeHandle = {
  tilt: HTMLDivElement | null;
  card: HTMLDivElement | null;
  flap: HTMLDivElement | null;
  sealL: HTMLDivElement | null;
  sealR: HTMLDivElement | null;
  sealWrap: HTMLDivElement | null;
  flecks: HTMLSpanElement[];
  glow: HTMLDivElement | null;
  flare: HTMLDivElement | null;
  shell: HTMLElement[];
};

/** Black-and-gold CSS 3D envelope: body, lining, card, front pocket, flap and split-able wax seal. */
export const Envelope = forwardRef<EnvelopeHandle>(function Envelope(_, ref) {
  const tilt = useRef<HTMLDivElement>(null);
  const card = useRef<HTMLDivElement>(null);
  const flap = useRef<HTMLDivElement>(null);
  const sealL = useRef<HTMLDivElement>(null);
  const sealR = useRef<HTMLDivElement>(null);
  const sealWrap = useRef<HTMLDivElement>(null);
  const glow = useRef<HTMLDivElement>(null);
  const flare = useRef<HTMLDivElement>(null);
  const flecks = useRef<HTMLSpanElement[]>([]);
  const back = useRef<HTMLDivElement>(null);
  const lining = useRef<HTMLDivElement>(null);
  const front = useRef<HTMLDivElement>(null);

  useImperativeHandle(ref, () => ({
    get tilt() { return tilt.current; },
    get card() { return card.current; },
    get flap() { return flap.current; },
    get sealL() { return sealL.current; },
    get sealR() { return sealR.current; },
    get sealWrap() { return sealWrap.current; },
    get glow() { return glow.current; },
    get flare() { return flare.current; },
    get flecks() { return flecks.current.filter(Boolean); },
    get shell() {
      return [back.current, lining.current, front.current, flap.current, sealWrap.current].filter(Boolean) as HTMLElement[];
    },
  }));

  const mono = content.invitation.sealMonogram || "R";

  return (
    <div className="relative" style={{ perspective: "1200px" }}>
      <div ref={tilt} className="relative" style={{ transformStyle: "preserve-3d" }}>
        <div className="relative aspect-[3/2] w-[min(76vw,300px)]" style={{ perspective: "1200px" }}>
          {/* Light pouring from inside */}
          <div
            ref={glow}
            aria-hidden="true"
            className="pointer-events-none absolute left-1/2 top-[10%] z-[1] h-[260%] w-[260%] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-0"
            style={{
              background:
                "radial-gradient(circle, color-mix(in oklab, var(--gold-light) 95%, transparent) 0%, color-mix(in oklab, var(--gold) 55%, transparent) 22%, transparent 60%)",
            }}
          />
          {/* Back body + gold foil edge + rim light */}
          <div ref={back} className="env-body rim-light absolute inset-0 z-[2] rounded-md">
            <div className="absolute inset-[10px] rounded-sm border border-gold/20" />
          </div>
          {/* Inner lining */}
          <div ref={lining} className="env-lining absolute inset-x-[5px] top-[5px] z-[3] h-[58%] rounded-t-sm" />
          {/* Invitation card */}
          <div
            ref={card}
            className="invite-card absolute inset-x-[7%] top-[7%] z-[4] flex h-[86%] flex-col items-center justify-center rounded-sm text-center"
            style={{ transformOrigin: "50% 50%" }}
          >
            <span className="font-sans text-[0.5rem] tracking-[0.4em] text-gold-light/80">YOU ARE INVITED</span>
            <span className="text-gold mt-1 font-display text-3xl font-semibold tracking-[0.12em]">{content.invitation.title}</span>
            <span className="gold-rule my-2 w-20" />
            <span className="font-display text-xs italic text-ivory/80">The Grand Freshers Party</span>
          </div>
          {/* Front pocket */}
          <div ref={front} className="absolute inset-0 z-[5]">
            <div className="env-front absolute inset-0 rounded-b-md" />
            <div className="env-front-edge absolute inset-0" />
            {/* embossed detail */}
            <div className="absolute bottom-3 left-0 right-0 text-center font-display text-[0.6rem] tracking-[0.5em] text-gold/50">
              MITK · KUNDAPURA
            </div>
          </div>
          {/* Flap — two faces */}
          <div
            ref={flap}
            className="absolute inset-x-0 top-0 z-[6] h-[56%]"
            style={{ transformOrigin: "50% 0%", transformStyle: "preserve-3d" }}
          >
            <div className="env-flap absolute inset-0" style={{ backfaceVisibility: "hidden" }} />
            <div className="env-flap-edge absolute inset-0" style={{ backfaceVisibility: "hidden" }} />
            <div
              className="env-lining absolute inset-0"
              style={{ backfaceVisibility: "hidden", transform: "rotateX(180deg)", clipPath: "polygon(0 0, 100% 0, 50% 100%)" }}
            />
          </div>
          {/* Wax seal */}
          <div ref={sealWrap} className="absolute left-1/2 top-[56%] z-[7] h-14 w-14 -translate-x-1/2 -translate-y-1/2">
            <div ref={sealL} className="wax-seal absolute inset-0 rounded-full" style={{ clipPath: "polygon(0 0, 52% 0, 46% 35%, 54% 60%, 48% 100%, 0 100%)" }}>
              <span className="absolute inset-0 flex items-center justify-center font-display text-2xl font-bold text-gold-deep">{mono}</span>
              <span className="absolute inset-[5px] rounded-full border border-gold-deep/60" />
            </div>
            <div ref={sealR} className="wax-seal absolute inset-0 rounded-full" style={{ clipPath: "polygon(52% 0, 100% 0, 100% 100%, 48% 100%, 54% 60%, 46% 35%)" }}>
              <span className="absolute inset-0 flex items-center justify-center font-display text-2xl font-bold text-gold-deep">{mono}</span>
              <span className="absolute inset-[5px] rounded-full border border-gold-deep/60" />
            </div>
            {Array.from({ length: 10 }).map((_, i) => (
              <span
                key={i}
                ref={(el) => { if (el) flecks.current[i] = el; }}
                aria-hidden="true"
                className="absolute left-1/2 top-1/2 h-1.5 w-1.5 rounded-[1px] bg-gold-light opacity-0"
              />
            ))}
          </div>
          {/* Lens flare */}
          <div
            ref={flare}
            aria-hidden="true"
            className="pointer-events-none absolute left-1/2 top-[8%] z-[8] h-[3px] w-[180%] -translate-x-1/2 opacity-0"
            style={{ background: "linear-gradient(90deg, transparent, var(--gold-light), var(--ivory), var(--gold-light), transparent)" }}
          />
        </div>
      </div>
    </div>
  );
});
