/** Soft pre-blurred golden bokeh orbs drifting at different depths (transform/opacity only). */
const ORBS = [
  { x: "8%", y: "18%", s: 140, d: "14s", delay: "0s", o: 0.35, anim: "float-a" },
  { x: "72%", y: "10%", s: 90, d: "18s", delay: "-4s", o: 0.3, anim: "float-b" },
  { x: "60%", y: "52%", s: 180, d: "22s", delay: "-8s", o: 0.22, anim: "float-a" },
  { x: "14%", y: "70%", s: 70, d: "16s", delay: "-2s", o: 0.4, anim: "float-b" },
  { x: "82%", y: "80%", s: 120, d: "20s", delay: "-11s", o: 0.25, anim: "float-a" },
  { x: "40%", y: "34%", s: 46, d: "12s", delay: "-6s", o: 0.5, anim: "float-b" },
  { x: "28%", y: "90%", s: 54, d: "15s", delay: "-3s", o: 0.45, anim: "float-a" },
];

export function FloatingLights({ className = "", dense = false }: { className?: string; dense?: boolean }) {
  const orbs = dense ? ORBS : ORBS.slice(0, 5);
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {orbs.map((o, i) => (
        <span
          key={i}
          className="absolute rounded-full"
          style={{
            left: o.x,
            top: o.y,
            width: o.s,
            height: o.s,
            opacity: o.o,
            background:
              "radial-gradient(circle, color-mix(in oklab, var(--gold-light) 70%, transparent) 0%, color-mix(in oklab, var(--gold) 30%, transparent) 35%, transparent 70%)",
            animation: `${o.anim} ${o.d} var(--ease-silk) ${o.delay} infinite`,
            willChange: "transform",
          }}
        />
      ))}
    </div>
  );
}

/** Warm sunrise light rays (morning event — never night imagery). */
export function SunriseRays({ className = "", strength = 1 }: { className?: string; strength?: number }) {
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      <div className="absolute inset-0" style={{ background: "var(--gradient-sunrise)", opacity: strength }} />
      <div
        className="anim-rays-slow absolute left-1/2 -top-[60%] aspect-square w-[220%] -translate-x-1/2"
        style={{
          opacity: 0.18 * strength,
          background:
            "repeating-conic-gradient(from 0deg, color-mix(in oklab, var(--gold-light) 55%, transparent) 0deg 3deg, transparent 3deg 18deg)",
          WebkitMask: "radial-gradient(circle, #000 0%, transparent 55%)",
          mask: "radial-gradient(circle, #000 0%, transparent 55%)",
        }}
      />
    </div>
  );
}
