import { useEffect, useId, useRef, useState } from "react";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/** Floating-label input with a gold underline expanding from center and a focus glow ring. */
export function FormStep({
  label, value, onChange, error, shake = 0, placeholder, autoComplete, onEnter, inputMode, maxLength, autoCapitalize,
}: {
  shake?: number;
  label: string; value: string; onChange: (v: string) => void; error?: string; placeholder?: string;
  autoComplete?: string; onEnter?: () => void; inputMode?: "text"; maxLength?: number; autoCapitalize?: string;
}) {
  const id = useId();
  const [focus, setFocus] = useState(false);
  const reduced = useReducedMotion();
  const floated = focus || value.length > 0;
  const wrap = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!shake || reduced || !wrap.current) return;
    wrap.current.animate(
      [{ transform: "translateX(0)" }, { transform: "translateX(-6px)" }, { transform: "translateX(6px)" }, { transform: "translateX(0)" }],
      { duration: 360, iterations: 2, easing: "cubic-bezier(0.65,0,0.35,1)" },
    );
  }, [shake, reduced]);
  return (
    <div ref={wrap} className="w-full">
      <div className={`relative rounded-xl px-4 pb-2 pt-6 transition-shadow duration-500 ${focus ? "shadow-[var(--glow-gold-strong)]" : ""} glass-gold`}>
        <label
          htmlFor={id}
          className={`pointer-events-none absolute left-4 font-sans uppercase transition-all duration-500 ease-[var(--ease-luxe)] ${
            floated ? "top-2 text-[0.6rem] tracking-[0.3em] text-gold-light/80" : "top-[1.15rem] text-sm tracking-[0.12em] text-ivory/60"
          }`}
        >
          {label}
        </label>
        <input
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); onEnter?.(); } }}
          placeholder={focus ? placeholder : ""}
          autoComplete={autoComplete}
          inputMode={inputMode}
          maxLength={maxLength}
          autoCapitalize={autoCapitalize}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-err` : undefined}
          className="w-full bg-transparent pb-1 font-display text-xl text-ivory caret-gold outline-none placeholder:text-ivory/30"
        />
        <span className="absolute inset-x-4 bottom-1.5 h-px bg-gold/25" />
        <span
          className="absolute inset-x-4 bottom-1.5 h-px origin-center bg-gold-light transition-transform duration-700 ease-[var(--ease-luxe)]"
          style={{ transform: `scaleX(${focus ? 1 : 0})` }}
        />
      </div>
      <p id={`${id}-err`} role="alert" aria-live="assertive" className={`mt-2 min-h-5 font-sans text-xs ${error ? "text-destructive" : ""}`}>
        {error ?? ""}
      </p>
    </div>
  );
}
