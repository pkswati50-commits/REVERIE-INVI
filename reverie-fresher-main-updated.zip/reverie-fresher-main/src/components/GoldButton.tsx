import { forwardRef, type ButtonHTMLAttributes } from "react";
import { chime, haptic } from "@/lib/sound";
import { cn } from "@/lib/utils";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & { solid?: boolean; size?: "md" | "lg" | "sm" };

/** Glowing gold pill button: breathing glow, shimmer sweep every 4s, press scale 0.97, haptic. */
export const GoldButton = forwardRef<HTMLButtonElement, Props>(function GoldButton(
  { className, solid, size = "md", onClick, children, ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      {...rest}
      onClick={(e) => {
        haptic();
        chime(0.5);
        onClick?.(e);
      }}
      className={cn(
        "gold-pill inline-flex items-center justify-center gap-2 font-sans font-medium uppercase",
        size === "lg" && "px-8 py-4 text-[0.78rem]",
        size === "md" && "px-6 py-3 text-[0.72rem]",
        size === "sm" && "px-4 py-2 text-[0.65rem]",
        solid && "gold-solid",
        className,
      )}
    >
      {children}
    </button>
  );
});
