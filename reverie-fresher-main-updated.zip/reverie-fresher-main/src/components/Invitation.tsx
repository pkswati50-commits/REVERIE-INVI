import { Suspense, lazy, useCallback, useEffect, useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { OpeningSequence } from "@/sections/Opening";
import { CollegeSection } from "@/sections/College";
import { EventDetailsSection } from "@/sections/EventDetails";
import type { FresherData } from "@/sections/Experience";
import { Particles } from "@/components/Particles";
import { FloatingLights, SunriseRays } from "@/components/FloatingLights";
import { useScrollLock } from "@/hooks/useScrollLock";
import { setSoundEnabled } from "@/lib/sound";

// below-the-fold sections load lazily
const ExperienceSection = lazy(() => import("@/sections/Experience").then((m) => ({ default: m.ExperienceSection })));
const PosterSection = lazy(() => import("@/sections/Poster").then((m) => ({ default: m.PosterSection })));
const MessagesSection = lazy(() => import("@/sections/Messages").then((m) => ({ default: m.MessagesSection })));
const FinaleSection = lazy(() => import("@/sections/FinaleSection").then((m) => ({ default: m.FinaleSection })));

const NAV = [
  { id: "college", label: "Welcome" },
  { id: "details", label: "Event details" },
  { id: "experience", label: "Confirm your presence" },
  { id: "poster", label: "Official poster" },
  { id: "messages", label: "Special messages" },
  { id: "finale", label: "Finale" },
];

const EMPTY: FresherData = { fullName: "", branch: "", answers: [] };

function SectionFallback() {
  return (
    <div className="flex min-h-stage items-center justify-center" role="status" aria-label="Loading">
      <span className="h-px w-24 animate-pulse bg-gold/50" />
    </div>
  );
}

export function Invitation() {
  const [runKey, setRunKey] = useState(0);
  const [phase, setPhase] = useState<"opening" | "main">("opening");
  const [revealed, setRevealed] = useState(false);
  const [data, setData] = useState<FresherData>(EMPTY);
  const [sound, setSound] = useState(false);
  const [progress, setProgress] = useState(0);
  const [active, setActive] = useState("college");
  const scrollerRef = useRef<HTMLDivElement>(null);

  useScrollLock(scrollerRef, phase !== "main");

  // progress indicator + active dot
  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const max = el.scrollHeight - el.clientHeight;
        setProgress(max > 0 ? el.scrollTop / max : 0);
        const mid = el.scrollTop + el.clientHeight * 0.45;
        let current = NAV[0].id;
        for (const n of NAV) {
          const s = el.querySelector<HTMLElement>(`[data-section="${n.id}"]`);
          if (s && s.offsetTop <= mid) current = n.id;
        }
        setActive(current);
      });
    };
    el.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => { el.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, [runKey]);

  const jump = (id: string) => {
    const el = scrollerRef.current;
    const s = el?.querySelector<HTMLElement>(`[data-section="${id}"]`);
    if (el && s) el.scrollTo({ top: s.offsetTop, behavior: "smooth" });
  };

  const onReveal = useCallback(() => setRevealed(true), []);
  const onDone = useCallback(() => setPhase("main"), []);

  const replay = () => {
    scrollerRef.current?.scrollTo({ top: 0 });
    setData(EMPTY);
    setRevealed(false);
    setPhase("opening");
    setProgress(0);
    setActive("college");
    setRunKey((k) => k + 1);
  };

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    setSoundEnabled(next);
  };

  const main = phase === "main";

  return (
    <div className="gold-dust-backdrop fixed inset-0 flex items-center justify-center overflow-hidden">
      {/* desktop backdrop gold dust */}
      <div aria-hidden="true" className="absolute inset-0 hidden sm:block">
        <Particles mode="dust" count={70} />
        <FloatingLights dense />
      </div>

      <main
        className="relative h-stage w-full overflow-hidden bg-black-deep sm:w-auto sm:aspect-[390/844] sm:rounded-[2.25rem] sm:border sm:border-gold/30 sm:shadow-[var(--glow-gold)]"
        aria-label="REVERIE invitation"
      >
        {/* ambient layers */}
        <SunriseRays />
        <Particles mode="dust" count={45} />
        <FloatingLights className="opacity-80" />

        <div
          ref={scrollerRef}
          data-scroller
          className="no-scrollbar absolute inset-0 z-10 overflow-x-hidden overscroll-contain"
          style={{ overflowY: "hidden", WebkitOverflowScrolling: "touch" }}
        >
          <div key={runKey}>
            <CollegeSection revealed={revealed} />
            <EventDetailsSection />
            <Suspense fallback={<SectionFallback />}>
              <ExperienceSection data={data} setData={setData} />
              <PosterSection />
              <MessagesSection />
              <FinaleSection name={data.fullName} onReplay={replay} />
            </Suspense>
          </div>
        </div>

        {/* gold progress indicator */}
        <div aria-hidden="true" className={`absolute inset-x-0 top-0 z-20 h-[2px] transition-opacity duration-700 ${main ? "opacity-100" : "opacity-0"}`}>
          <div className="h-full origin-left" style={{ transform: `scaleX(${progress})`, background: "var(--gradient-gold-soft)" }} />
        </div>

        {/* dot navigation */}
        <nav
          aria-label="Sections"
          className={`absolute right-2.5 top-1/2 z-20 flex -translate-y-1/2 flex-col gap-3 transition-opacity duration-700 ${main ? "opacity-100" : "pointer-events-none opacity-0"}`}
        >
          {NAV.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => jump(n.id)}
              aria-label={n.label}
              aria-current={active === n.id ? "true" : undefined}
              className="group flex h-4 w-4 items-center justify-center"
            >
              <span
                className={`block rounded-full transition-all duration-500 ${
                  active === n.id ? "h-2.5 w-2.5 bg-gold shadow-[var(--glow-gold-strong)]" : "h-1.5 w-1.5 bg-gold/40 group-hover:bg-gold/80"
                }`}
              />
            </button>
          ))}
        </nav>

        {/* sound toggle (off by default) */}
        <button
          type="button"
          onClick={toggleSound}
          aria-pressed={sound}
          aria-label={sound ? "Turn sound off" : "Turn sound on"}
          className="absolute left-4 top-[calc(var(--safe-top)+1rem)] z-[70] flex h-9 w-9 items-center justify-center rounded-full border border-gold/40 bg-black-deep/60 text-gold-light transition-colors hover:border-gold hover:text-ivory"
        >
          {sound ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
        </button>

        {phase === "opening" && <OpeningSequence key={runKey} onReveal={onReveal} onDone={onDone} />}
      </main>
    </div>
  );
}
