import { useEffect, useRef } from "react";
import { getDeviceTier } from "@/hooks/useDeviceTier";
import { prefersReducedMotion } from "@/hooks/useReducedMotion";

/**
 * One shared Canvas 2D particle engine.
 * - dust:     tiny gold motes drifting upward with sway + twinkle
 * - sparkle:  four-point star glints that twinkle (intensity adjustable live)
 * - confetti: two bottom-corner cannons (rects, ribbons, stars) that settle into sparkles
 */
type Mode = "dust" | "sparkle" | "confetti";

type P = {
  x: number; y: number; vx: number; vy: number; size: number; life: number; max: number;
  rot: number; vr: number; phase: number; hue: number; shape: 0 | 1 | 2; depth: number; conf: boolean;
};

const GOLDS = [
  [246, 226, 122],
  [212, 175, 55],
  [255, 236, 170],
  [180, 140, 40],
  [245, 235, 208],
];

export function Particles({
  mode = "dust",
  count = 50,
  intensityRef,
  fire = false,
  className = "",
}: {
  mode?: Mode;
  count?: number;
  /** live multiplier (1 = normal) read every frame */
  intensityRef?: { current: number };
  /** confetti: start the cannons when true */
  fire?: boolean;
  className?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fireRef = useRef(fire);
  fireRef.current = fire;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (prefersReducedMotion()) return; // particles & confetti disabled under reduced motion
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const tier = getDeviceTier();
    const dpr = tier.dpr;
    let w = 0, h = 0;
    let raf = 0;
    let running = true;
    let visible = true;
    let parts: P[] = [];
    let fired = false;
    let fireStart = 0;
    const cap = tier.mobile ? 120 : 250;
    const base = Math.round((tier.lowEnd ? count * 0.5 : count));

    const resize = () => {
      const r = canvas.getBoundingClientRect();
      w = Math.max(1, r.width);
      h = Math.max(1, r.height);
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const ambient = (initial: boolean): P => {
      const depth = Math.random();
      return {
        x: Math.random() * w,
        y: initial ? Math.random() * h : h + 10,
        vx: (Math.random() - 0.5) * 0.15,
        vy: -(0.12 + Math.random() * 0.35) * (0.5 + depth),
        size: mode === "sparkle" ? 1.5 + Math.random() * 3.5 : 0.6 + Math.random() * 1.8 * (0.5 + depth),
        life: initial ? Math.random() * 400 : 0,
        max: 300 + Math.random() * 500,
        rot: Math.random() * Math.PI,
        vr: (Math.random() - 0.5) * 0.01,
        phase: Math.random() * Math.PI * 2,
        hue: Math.floor(Math.random() * GOLDS.length),
        shape: 0,
        depth,
        conf: false,
      };
    };

    if (mode !== "confetti") for (let i = 0; i < base; i++) parts.push(ambient(true));

    const burst = () => {
      const n = Math.floor(Math.min(cap, base) / 2);
      for (let i = 0; i < n; i++) {
        const left = i % 2 === 0;
        const angle = (left ? -Math.PI / 2 + 0.35 : -Math.PI / 2 - 0.35) + (Math.random() - 0.5) * 0.7;
        const speed = 7 + Math.random() * 7;
        parts.push({
          x: left ? -4 : w + 4,
          y: h + 4,
          vx: Math.cos(angle) * speed * (0.6 + Math.random() * 0.5),
          vy: Math.sin(angle) * speed * (0.9 + Math.random() * 0.4),
          size: 4 + Math.random() * 6,
          life: 0,
          max: 260 + Math.random() * 80,
          rot: Math.random() * Math.PI * 2,
          vr: (Math.random() - 0.5) * 0.3,
          phase: Math.random() * Math.PI * 2,
          hue: Math.floor(Math.random() * GOLDS.length),
          shape: (Math.floor(Math.random() * 3) as 0 | 1 | 2),
          depth: Math.random(),
          conf: true,
        });
      }
    };

    const star = (x: number, y: number, r: number) => {
      ctx.beginPath();
      ctx.moveTo(x, y - r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.quadraticCurveTo(x, y, x, y + r);
      ctx.quadraticCurveTo(x, y, x - r, y);
      ctx.quadraticCurveTo(x, y, x, y - r);
      ctx.fill();
    };

    let last = performance.now();
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (!running || !visible) { last = now; return; }
      const dt = Math.min(2.5, (now - last) / 16.67);
      last = now;
      ctx.clearRect(0, 0, w, h);
      const intensity = intensityRef?.current ?? 1;

      if (mode === "confetti" && fireRef.current && !fired) {
        fired = true;
        fireStart = now;
        burst();
        setTimeout(() => running && burst(), 450);
      }
      // after ~5s confetti settles into gentle sparkles
      if (mode === "confetti" && fired && now - fireStart > 4500 && parts.filter((q) => !q.conf).length < 28) {
        const sp = ambient(true);
        sp.size = 1.2 + Math.random() * 2;
        parts.push(sp);
      }

      const next: P[] = [];
      for (const p of parts) {
        p.life += dt;
        if (p.conf) {
          p.vy += 0.16 * dt; // gravity
          p.vx *= Math.pow(0.985, dt); // drag
          p.vy *= Math.pow(0.99, dt);
          p.x += p.vx * dt + Math.sin(p.life * 0.05 + p.phase) * 0.6;
          p.y += p.vy * dt;
          p.rot += p.vr * dt;
          if (p.y > h + 30 || p.life > p.max) continue;
          const c = GOLDS[p.hue];
          const fade = Math.min(1, (p.max - p.life) / 40);
          ctx.globalAlpha = fade;
          ctx.fillStyle = `rgb(${c[0]},${c[1]},${c[2]})`;
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          if (p.shape === 0) {
            ctx.scale(1, Math.abs(Math.cos(p.life * 0.12 + p.phase)) + 0.15);
            ctx.fillRect(-p.size / 2, -p.size / 3, p.size, p.size * 0.66);
          } else if (p.shape === 1) {
            ctx.fillRect(-p.size * 0.15, -p.size, p.size * 0.3, p.size * 2.2);
          } else {
            star(0, 0, p.size * 0.8);
          }
          ctx.restore();
          next.push(p);
          continue;
        }
        // ambient dust / sparkle
        p.x += (p.vx + Math.sin(p.life * 0.02 + p.phase) * 0.15) * dt;
        p.y += p.vy * dt * (0.6 + intensity * 0.4);
        if (p.y < -10 || p.life > p.max) {
          next.push(ambient(false));
          continue;
        }
        const tw = 0.35 + 0.65 * Math.abs(Math.sin(p.life * 0.04 + p.phase));
        const edge = Math.min(1, p.life / 40, (p.max - p.life) / 60);
        const c = GOLDS[p.hue];
        ctx.globalAlpha = Math.max(0, Math.min(1, tw * edge * (0.5 + 0.5 * p.depth) * Math.min(1.6, intensity)));
        ctx.fillStyle = `rgb(${c[0]},${c[1]},${c[2]})`;
        const s = p.size * (mode === "sparkle" ? 0.6 + intensity * 0.4 : 1);
        if (mode !== "dust") star(p.x, p.y, s * tw * 1.6);
        else {
          ctx.beginPath();
          ctx.arc(p.x, p.y, s, 0, Math.PI * 2);
          ctx.fill();
        }
        next.push(p);
      }
      // extra sparkles at peak intensity
      if (mode === "sparkle" && intensity > 1.2 && next.length < base * intensity * 1.2) {
        for (let i = 0; i < 2; i++) next.push(ambient(true));
      }
      parts = next;
      ctx.globalAlpha = 1;
    };
    raf = requestAnimationFrame(tick);

    const onVis = () => { running = document.visibilityState === "visible"; };
    document.addEventListener("visibilitychange", onVis);
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; });
    io.observe(canvas);

    return () => {
      cancelAnimationFrame(raf);
      running = false;
      ro.disconnect();
      io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      parts = [];
    };
  }, [mode, count, intensityRef]);

  return <canvas ref={canvasRef} aria-hidden="true" className={`pointer-events-none absolute inset-0 h-full w-full ${className}`} />;
}
