import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Minus, Plus, X } from "lucide-react";
import { content } from "@/config/content";
import { EASE_LUXE } from "@/animations/easing";

/** Full-screen poster viewer: object-fit contain, pinch / wheel / button zoom, drag to pan. Image pixels untouched. */
export function PosterViewer({ onClose }: { onClose: () => void }) {
  const { poster } = content.assets;
  const [scale, setScale] = useState(1);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinch = useRef<{ d: number; s: number } | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const clamp = (s: number) => Math.min(4, Math.max(1, s));
  const setZoom = (s: number) => {
    const c = clamp(s);
    setScale(c);
    if (c === 1) setPos({ x: 0, y: 0 });
  };

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col bg-black-deep/95"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      role="dialog"
      aria-modal="true"
      aria-label="Official poster — full screen"
    >
      <div
        className="relative flex-1 touch-none overflow-hidden"
        onWheel={(e) => setZoom(scale - e.deltaY * 0.002)}
        onDoubleClick={() => setZoom(scale > 1 ? 1 : 2.2)}
        onPointerDown={(e) => {
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
          if (pointers.current.size === 2) {
            const [a, b] = [...pointers.current.values()];
            pinch.current = { d: Math.hypot(a.x - b.x, a.y - b.y), s: scale };
          }
        }}
        onPointerMove={(e) => {
          const prev = pointers.current.get(e.pointerId);
          if (!prev) return;
          pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
          if (pointers.current.size === 2 && pinch.current) {
            const [a, b] = [...pointers.current.values()];
            setZoom(pinch.current.s * (Math.hypot(a.x - b.x, a.y - b.y) / pinch.current.d));
          } else if (pointers.current.size === 1 && scale > 1) {
            setPos((p) => ({ x: p.x + (e.clientX - prev.x), y: p.y + (e.clientY - prev.y) }));
          }
        }}
        onPointerUp={(e) => { pointers.current.delete(e.pointerId); if (pointers.current.size < 2) pinch.current = null; }}
        onPointerCancel={(e) => { pointers.current.delete(e.pointerId); pinch.current = null; }}
      >
        <motion.div layoutId="poster" className="absolute inset-0 flex items-center justify-center p-4" transition={{ duration: 0.6, ease: EASE_LUXE }}>
          <img
            src={poster.src}
            alt={poster.alt}
            width={poster.width}
            height={poster.height}
            draggable={false}
            className="max-h-full max-w-full select-none object-contain"
            style={{ transform: `translate3d(${pos.x}px, ${pos.y}px, 0) scale(${scale})`, transition: pointers.current.size ? "none" : "transform 0.3s var(--ease-luxe)" }}
          />
        </motion.div>
      </div>
      <div className="flex items-center justify-center gap-3 pb-[calc(var(--safe-bottom)+1rem)] pt-3">
        <button type="button" onClick={() => setZoom(scale - 0.5)} aria-label="Zoom out" className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 text-gold-light hover:border-gold">
          <Minus className="h-4 w-4" />
        </button>
        <span className="w-14 text-center font-mono text-xs text-gold-light/80">{Math.round(scale * 100)}%</span>
        <button type="button" onClick={() => setZoom(scale + 0.5)} aria-label="Zoom in" className="flex h-10 w-10 items-center justify-center rounded-full border border-gold/50 text-gold-light hover:border-gold">
          <Plus className="h-4 w-4" />
        </button>
      </div>
      <button
        ref={closeRef}
        type="button"
        onClick={onClose}
        aria-label="Close poster"
        className="absolute right-4 top-[calc(var(--safe-top)+1rem)] flex h-11 w-11 items-center justify-center rounded-full border border-gold/60 bg-black-deep/70 text-gold-light hover:border-gold-light hover:text-ivory"
      >
        <X className="h-5 w-5" />
      </button>
    </motion.div>
  );
}
