import { useState } from "react";
import { motion } from "framer-motion";
import { EASE_LUXE } from "@/animations/easing";
import { chime, haptic } from "@/lib/sound";

/** Question with two answers: glow on hover, ripple on tap, selected fills gold with a drawn check. */
export function QuestionCard({
  index, total, question, options, selected, onSelect,
}: { index: number; total: number; question: string; options: string[]; selected?: string; onSelect: (v: string) => void }) {
  const [ripple, setRipple] = useState<{ x: number; y: number; k: number; opt: string } | null>(null);
  return (
    <div className="w-full text-center">
      <p className="font-mono text-[0.7rem] text-gold/70">question {index + 1} / {total}</p>
      <h3 className="mt-3 font-display text-[1.7rem] font-semibold leading-snug text-ivory">{question}</h3>
      <div className="mt-8 flex flex-col gap-3" role="radiogroup" aria-label={question}>
        {options.map((opt) => {
          const isSel = selected === opt;
          return (
            <button
              key={opt}
              type="button"
              role="radio"
              aria-checked={isSel}
              onClick={(e) => {
                const r = e.currentTarget.getBoundingClientRect();
                setRipple({ x: e.clientX - r.left, y: e.clientY - r.top, k: Date.now(), opt });
                haptic();
                chime(0.5);
                onSelect(opt);
              }}
              className={`relative flex items-center justify-center gap-3 overflow-hidden rounded-full border px-6 py-4 font-sans text-sm font-semibold uppercase tracking-[0.18em] transition-all duration-500 ease-[var(--ease-luxe)] ${
                isSel
                  ? "border-gold-light bg-gold text-black-deep shadow-[var(--glow-gold-strong)]"
                  : "border-gold/45 bg-black-deep/40 text-gold-light hover:border-gold hover:shadow-[var(--glow-gold)]"
              }`}
            >
              {ripple && ripple.opt === opt && (
                <motion.span
                  key={ripple.k}
                  aria-hidden="true"
                  className="absolute h-10 w-10 rounded-full bg-gold-light/50"
                  style={{ left: ripple.x - 20, top: ripple.y - 20 }}
                  initial={{ scale: 0, opacity: 0.8 }}
                  animate={{ scale: 9, opacity: 0 }}
                  transition={{ duration: 0.8, ease: EASE_LUXE }}
                />
              )}
              {isSel && (
                <svg viewBox="0 0 24 24" className="relative h-5 w-5" aria-hidden="true">
                  <motion.path
                    d="M4 12.5 L9.5 18 L20 6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.4"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    initial={{ pathLength: 0 }}
                    animate={{ pathLength: 1 }}
                    transition={{ duration: 0.5, ease: EASE_LUXE }}
                  />
                </svg>
              )}
              <span className="relative">{opt}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
