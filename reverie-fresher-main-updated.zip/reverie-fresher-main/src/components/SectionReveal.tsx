import { forwardRef, type ReactNode } from "react";

/** Full-height section shell used by every scene (also a dot-nav anchor). */
export const SectionShell = forwardRef<HTMLElement, { id: string; label: string; children: ReactNode; className?: string }>(
  function SectionShell({ id, label, children, className = "" }, ref) {
    return (
      <section
        ref={ref}
        id={id}
        data-section={id}
        aria-label={label}
        className={`relative flex min-h-stage w-full flex-col items-center justify-center overflow-hidden px-6 py-20 ${className}`}
      >
        {children}
      </section>
    );
  },
);

export function Ornament({ className = "" }: { className?: string }) {
  return (
    <div aria-hidden="true" className={`flex items-center justify-center gap-3 ${className}`}>
      <span className="gold-rule w-16" />
      <svg width="14" height="14" viewBox="0 0 14 14" className="text-gold">
        <path d="M7 0 L8.5 5.5 L14 7 L8.5 8.5 L7 14 L5.5 8.5 L0 7 L5.5 5.5 Z" fill="currentColor" />
      </svg>
      <span className="gold-rule w-16" />
    </div>
  );
}
