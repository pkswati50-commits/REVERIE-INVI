import { motion } from "framer-motion";
import { EASE_LUXE } from "@/animations/easing";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/** Letter-by-letter blur-to-sharp rise with tightening letter spacing. */
export function LetterReveal({
  text, className = "", delay = 0, stagger = 0.05, play = true,
}: { text: string; className?: string; delay?: number; stagger?: number; play?: boolean }) {
  const reduced = useReducedMotion();
  return (
    <motion.span
      aria-label={text}
      className={`inline-block ${className}`}
      initial={{ letterSpacing: reduced ? "0.18em" : "0.5em" }}
      animate={play ? { letterSpacing: "0.18em" } : undefined}
      transition={{ duration: 2.2, delay, ease: EASE_LUXE }}
    >
      {Array.from(text).map((ch, i) => (
        <motion.span
          key={i}
          aria-hidden="true"
          className="inline-block"
          initial={reduced ? { opacity: 0 } : { opacity: 0, y: 14, filter: "blur(8px)" }}
          animate={play ? { opacity: 1, y: 0, filter: "blur(0px)" } : undefined}
          transition={{ duration: reduced ? 0.4 : 1.1, delay: delay + i * stagger, ease: EASE_LUXE }}
        >
          {ch === " " ? "\u00A0" : ch}
        </motion.span>
      ))}
    </motion.span>
  );
}

/** Word-by-word blur-to-sharp reveal; words in `highlight` render in gold. Supports \n line breaks. */
export function WordReveal({
  text, className = "", highlight = [], delay = 0, stagger = 0.06, play = true, goldClass = "text-gold font-semibold",
}: {
  text: string; className?: string; highlight?: string[]; delay?: number; stagger?: number; play?: boolean; goldClass?: string;
}) {
  const reduced = useReducedMotion();
  const lines = text.split("\n");
  let idx = 0;
  const hl = new Set(highlight.map((w) => w.toLowerCase()));
  return (
    <span className={className}>
      {lines.map((line, li) => (
        <span key={li} className="block">
          {line.split(/\s+/).filter(Boolean).map((word, wi) => {
            const i = idx++;
            const gold = hl.has(word.toLowerCase());
            return (
              <motion.span
                key={wi}
                className={`inline-block ${gold ? goldClass : ""}`}
                initial={reduced ? { opacity: 0 } : { opacity: 0, y: 10, filter: "blur(6px)" }}
                animate={play ? { opacity: 1, y: 0, filter: "blur(0px)" } : undefined}
                transition={{ duration: reduced ? 0.3 : 0.9, delay: delay + i * stagger, ease: EASE_LUXE }}
              >
                {word}
                {"\u00A0"}
              </motion.span>
            );
          })}
        </span>
      ))}
    </span>
  );
}

/** Mask reveal: content rises from behind an overflow-hidden line. */
export function MaskReveal({
  children, delay = 0, play = true, className = "", duration = 1.1,
}: { children: React.ReactNode; delay?: number; play?: boolean; className?: string; duration?: number }) {
  const reduced = useReducedMotion();
  return (
    <span className={`block overflow-hidden pb-[0.08em] ${className}`}>
      <motion.span
        className="block"
        initial={reduced ? { opacity: 0 } : { y: "110%", opacity: 0 }}
        animate={play ? { y: "0%", opacity: 1 } : undefined}
        transition={{ duration: reduced ? 0.4 : duration, delay, ease: EASE_LUXE }}
      >
        {children}
      </motion.span>
    </span>
  );
}
