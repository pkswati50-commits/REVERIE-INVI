/**
 * REVERIE — single editable content file.
 * Every visible text and asset lives here. Leave a value as "" to show a
 * visible placeholder like "[EVENT DATE]" in the site instead of inventing data.
 */
import collegePhotoAvif from "@/assets/mitk-college-photo.avif.asset.json";
import collegePhotoJpg from "@/assets/mitk-college-photo.jpg.asset.json";
import collegeLogo from "@/assets/mitk-college-logo.jpg.asset.json";
import officialPoster from "@/assets/orgi.poster.jpeg";

export type SpecialMessage = {
  text: string;
  /** words to highlight in gold */
  highlight: string[];
};

export const content = {
  assets: {
    collegePhoto: {
      avif: collegePhotoAvif.url,
      fallback: collegePhotoJpg.url,
      width: 720,
      height: 480,
      alt: "Aerial view of the Moodlakatte Institute of Technology campus, Kundapura",
    },
    collegeLogo: { src: collegeLogo.url, width: 500, height: 500, alt: "MIT Kundapura logo" },
    poster: {
      src: officialPoster,
      width: 1024,
      height: 1536,
      alt: "Official REVERIE Freshers' Day poster",
    },
  },

  college: {
    name: "Moodlakatte Institute of Technology, Kundapura",
    departmentPrefix: "Department of",
    department: "Computer Science and Engineering",
    specialization: "Data Science",
  },

  invitation: {
    introTitle: "AN EXCLUSIVE INVITATION",
    introSubtitle: "Something Special Awaits You...",
    openButton: "OPEN YOUR INVITATION",
    sealMonogram: "R",
    title: "REVERIE",
    welcomesLine: "Proudly Welcomes You To",
    themeLine: "A Warm Welcome to Juniors",
    partyLine: "THE GRAND FRESHERS PARTY",
    taglines: ["A New Beginning.", "A New Journey.", "A Day to Remember."],
  },

  event: {
    name: "REVERIE – Freshers Party",
    session: "Morning Session",
    date: "26 November 2026",
    dateNote: "Thursday",
    time: "9:00 AM",
    venue: "MITK Auditorium",
    organizedBy: "Data Science",
  },

  experience: {
    heading: "BEFORE YOU ENTER THE REVERIE...",
    subtitle: "Let's Make This Invitation Official!",
    questions: [
      { q: "Are you ready for your Fresher's Party?", options: ["YES! Absolutely!", "OF COURSE!"] },

    ],
    personalLine: "Your Fresher party experience awaits!",
    confirmButton: "CONFIRM MY PRESENCE",
  },

  posterHeading: "THE DAY WE'VE BEEN WAITING FOR...",

  messagesHeading: "A MESSAGE FOR OUR FUTURE MEMORIES",
  specialMessages: [
    {
      text: "The Department of Computer Science and Engineering (Data Science) warmly welcomes our newest members to an exciting celebration of togetherness, talent and fun! 🖤\nLet's decode the moments, connect the minds and create memories that last forever.\nBecause the best memories are not just predicted, they're created!\n🎉 Get ready to celebrate, connect and make memories!\nWELCOME FRESHERS! 💙",
      highlight: ["togetherness,", "talent", "fun!", "decode", "memories", "created!", "WELCOME", "FRESHERS!"],
    },
    {
      text: "Let's turn data into memories and algorithms into friendships..!\nDecoding the unknown. Discovering the unexpected.. ❤️",
      highlight: ["data", "memories", "algorithms", "friendships..!", "unknown.", "unexpected.."],
    },
    {
      text: "\"Think beyond data. Dream beyond limits.\"\nDecode today. Innovate tomorrow.",
      highlight: ["data.", "limits.\"", "Decode", "Innovate"],
    },
  ] satisfies SpecialMessage[],

  finale: {
    title: "THE REVERIE AWAITS YOU!",
    line: "Get Ready to Shine, Celebrate and Create Memories That Last Forever.",
    seeYou: "SEE YOU AT REVERIE!",
    replay: "REPLAY THE INVITATION",
  },
};

/** Returns the value, or a visible "[LABEL]" placeholder when empty. */
export function show(value: string | undefined | null, label: string) {
  const v = (value ?? "").trim();
  return v.length ? v : `[${label}]`;
}
export function isPlaceholder(value: string | undefined | null) {
  return !(value ?? "").trim().length;
}
