import { useEffect, useState } from "react";

export type DeviceTier = { lowEnd: boolean; mobile: boolean; dpr: number };

export function getDeviceTier(): DeviceTier {
  if (typeof window === "undefined") return { lowEnd: false, mobile: true, dpr: 1 };
  const cores = navigator.hardwareConcurrency ?? 8;
  return {
    lowEnd: cores <= 4,
    mobile: window.matchMedia("(max-width: 639px)").matches,
    dpr: Math.min(window.devicePixelRatio || 1, 2),
  };
}

export function useDeviceTier() {
  const [tier, setTier] = useState<DeviceTier>({ lowEnd: false, mobile: true, dpr: 1 });
  useEffect(() => setTier(getDeviceTier()), []);
  return tier;
}
