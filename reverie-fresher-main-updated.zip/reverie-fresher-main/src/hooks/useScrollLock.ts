import { useEffect, type RefObject } from "react";

/** Locks scrolling on the given scroll container (and the page) while `locked`. */
export function useScrollLock(ref: RefObject<HTMLElement | null>, locked: boolean) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const prevEl = el.style.overflowY;
    const prevBody = document.body.style.overflow;
    if (locked) {
      el.style.overflowY = "hidden";
      document.body.style.overflow = "hidden";
    } else {
      el.style.overflowY = "auto";
    }
    return () => {
      el.style.overflowY = prevEl;
      document.body.style.overflow = prevBody;
    };
  }, [ref, locked]);
}
