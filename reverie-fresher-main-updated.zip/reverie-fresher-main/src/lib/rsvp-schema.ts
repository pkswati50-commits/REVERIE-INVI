import { z } from "zod";

export const nameSchema = z
  .string()
  .trim()
  .min(2, "Please enter your full name")
  .max(80, "Name must be under 80 characters")
  .regex(/^[\p{L}][\p{L} .'-]*$/u, "Use letters, spaces, dots or hyphens only");

export const branchSchema = z
  .string()
  .trim()
  .min(2, "Please enter your branch / department")
  .max(80, "Branch must be under 80 characters");

export const rsvpSchema = z.object({
  fullName: nameSchema,
  branch: branchSchema,
  answers: z.array(z.string().trim().min(1).max(60)).length(1, "Please answer the question"),
});

export type RsvpInput = z.input<typeof rsvpSchema>;
export type RsvpResult =
  | { status: "saved" }
  | { status: "not_configured" }
  | { status: "error"; message: string };
