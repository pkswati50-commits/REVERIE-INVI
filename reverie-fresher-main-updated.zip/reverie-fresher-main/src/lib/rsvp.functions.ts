import { createServerFn } from "@tanstack/react-start";
import { rsvpSchema, type RsvpResult } from "./rsvp-schema";

/**
 * Saves a fresher's confirmation. Public endpoint: input is fully validated,
 * Response details are never returned or logged, and the table has no public read access.
 */
export const confirmPresence = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => rsvpSchema.parse(input))
  .handler(async ({ data }): Promise<RsvpResult> => {
    if (!process.env["SUPABASE_URL"] || !process.env["SUPABASE_SERVICE_ROLE_KEY"]) {
      return { status: "not_configured" };
    }
    try {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { error } = await supabaseAdmin.from("fresher_rsvps").upsert(
        {
          full_name: data.fullName,
          usn: crypto.randomUUID().replaceAll("-", "").slice(0, 15),
          branch: data.branch,
          answers: { q1: data.answers[0] },
          updated_at: new Date().toISOString(),
        },
        { onConflict: "usn" },
      );
      if (error) {
        console.error("[rsvp] save failed", error.code);
        return { status: "error", message: "We couldn't save your response. Please try again." };
      }
      return { status: "saved" };
    } catch {
      console.error("[rsvp] save threw");
      return { status: "error", message: "We couldn't reach the server. Please try again." };
    }
  });
