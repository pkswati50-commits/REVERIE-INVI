/** Optional ambient sound — OFF by default, no autoplay. Pure WebAudio, no files. */
let ctx: AudioContext | null = null;
let enabled = false;
let pad: { stop: () => void } | null = null;

function getCtx() {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  return ctx;
}

export function isSoundEnabled() {
  return enabled;
}

export function setSoundEnabled(on: boolean) {
  enabled = on;
  const c = getCtx();
  if (!c) return;
  if (on) {
    void c.resume();
    startPad(c);
    chime(0.6);
  } else {
    pad?.stop();
    pad = null;
  }
}

function startPad(c: AudioContext) {
  if (pad) return;
  const master = c.createGain();
  master.gain.value = 0;
  master.gain.linearRampToValueAtTime(0.035, c.currentTime + 2.5);
  master.connect(c.destination);
  const oscs = [196, 246.94, 293.66].map((f, i) => {
    const o = c.createOscillator();
    o.type = "sine";
    o.frequency.value = f;
    o.detune.value = i * 4 - 4;
    o.connect(master);
    o.start();
    return o;
  });
  pad = {
    stop: () => {
      master.gain.cancelScheduledValues(c.currentTime);
      master.gain.setValueAtTime(master.gain.value, c.currentTime);
      master.gain.linearRampToValueAtTime(0, c.currentTime + 0.8);
      oscs.forEach((o) => o.stop(c.currentTime + 0.9));
    },
  };
}

/** Soft bell chime. */
export function chime(intensity = 1) {
  if (!enabled) return;
  const c = getCtx();
  if (!c) return;
  const now = c.currentTime;
  [880, 1318.5, 1760].forEach((f, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = "sine";
    o.frequency.value = f;
    g.gain.setValueAtTime(0, now);
    g.gain.linearRampToValueAtTime((0.08 / (i + 1)) * intensity, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 1.8);
    o.connect(g).connect(c.destination);
    o.start(now);
    o.stop(now + 1.9);
  });
}

export function stopAllSound() {
  pad?.stop();
  pad = null;
}

/** Light haptic tap where supported. */
export function haptic(ms = 12) {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* unsupported */
  }
}
