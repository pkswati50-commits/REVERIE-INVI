import { createFileRoute } from "@tanstack/react-router";
import { Invitation } from "@/components/Invitation";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "REVERIE — The Grand Freshers Invitation | MITK Data Science" },
      {
        name: "description",
        content:
          "Your exclusive invitation to REVERIE, the Freshers Party (morning session) by the Department of CSE – Data Science, Moodlakatte Institute of Technology, Kundapura.",
      },
      { property: "og:title", content: "REVERIE — The Grand Freshers Invitation" },
      {
        property: "og:description",
        content: "Open your golden invitation to REVERIE — a warm welcome to juniors at MITK Kundapura.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "theme-color", content: "#050505" },
    ],
  }),
  component: Index,
});

function Index() {
  return <Invitation />;
}
