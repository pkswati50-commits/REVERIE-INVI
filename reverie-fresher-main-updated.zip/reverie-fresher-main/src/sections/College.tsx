import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { content } from "@/config/content";
import { MaskReveal } from "@/components/TextReveal";
import { SectionShell, Ornament } from "@/components/SectionReveal";
import { EASE_LUXE } from "@/animations/easing";
import { useReducedMotion } from "@/hooks/useReducedMotion";

/** Typed tagline in three phrases with a gold underline drawing beneath. */
function TypedTagline({ play }: { play: boolean }) {
  const phrases = content.invitation.taglines;
  const full = phrases.join(" ");
  const [n, setN] = useState(0);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!play) return;
    if (reduced) { setN(full.length); return; }
    let i = 0;
    let t: ReturnType<typeof setTimeout>;
    const step = () => {
      i += 1;
      setN(i);
      if (i >= full.length) return;
      const pause = full[i - 1] === "." ? 420 : 45;
      t = setTimeout(step, pause);
    };
    t = setTimeout(step, 600);
    return () => clearTimeout(t);
  }, [play, full, reduced]);
  const done = n >= full.length;
  return (
    <div className="relative mt-8 inline-block">
      <p className="font-display text-lg italic text-ivory/90" aria-label={full}>
        <span aria-hidden="true">{full.slice(0, n)}</span>
        <span aria-hidden="true" className={`ml-0.5 inline-block h-5 w-px translate-y-1 bg-gold ${done ? "anim-caret" : ""}`} />
      </p>
      <motion.span
        className="gold-rule absolute -bottom-2 left-0 right-0 block origin-center"
        initial={{ scaleX: 0 }}
        animate={done ? { scaleX: 1 } : undefined}
        transition={{ duration: 1.4, ease: EASE_LUXE }}
      />
    </div>
  );
}

export function CollegeSection({ revealed }: { revealed: boolean }) {
  const reduced = useReducedMotion();
  const photoRef = useRef<HTMLDivElement>(null);
  const { college, invitation, assets } = content;

  // mild parallax on the photo while scrolling
  useEffect(() => {
    if (reduced) return;
    const el = photoRef.current;
    const scroller = el?.closest("[data-scroller]") as HTMLElement | null;
    if (!el || !scroller) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const y = Math.min(scroller.scrollTop, 600);
        el.style.transform = `translate3d(0, ${y * 0.12}px, 0)`;
      });
    };
    scroller.addEventListener("scroll", onScroll, { passive: true });
    return () => { scroller.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, [reduced]);

  const lines: { node: React.ReactNode; cls?: string }[] = [
    { node: <span className="font-display text-xl font-semibold uppercase leading-snug tracking-[0.08em] text-ivory">{college.name || "[COLLEGE NAME]"}</span> },
    { node: <span className="font-sans text-[0.7rem] uppercase tracking-[0.35em] text-gold-light/80">{college.departmentPrefix}</span>, cls: "mt-5" },
    { node: <span className="text-gold font-display text-2xl font-semibold uppercase leading-tight">{college.department || "[DEPARTMENT]"}</span>, cls: "mt-1" },
    { node: <span className="font-display text-base italic text-ivory/85">(Specialization: {college.specialization ? college.specialization.toUpperCase() : "[SPECIALIZATION]"})</span>, cls: "mt-1" },
    { node: <span className="font-sans text-[0.7rem] uppercase tracking-[0.35em] text-gold-light/80">{invitation.welcomesLine}</span>, cls: "mt-8" },
    { node: <span className="text-gold-loop font-display text-[1.9rem] font-semibold uppercase leading-tight tracking-[0.06em]">{invitation.themeLine}</span>, cls: "mt-2" },
    { node: <span className="font-sans text-sm font-medium uppercase tracking-[0.3em] text-ivory">{invitation.partyLine}</span>, cls: "mt-2" },
  ];

  const base = 1.9; // after title

  return (
    <SectionShell id="college" label="College introduction" className="justify-start pt-[calc(var(--safe-top)+4.5rem)]">
      {/* Photo with self-drawing double gold border */}
      <div className="relative w-full">
        <motion.div
          className="relative overflow-hidden rounded-sm"
          initial={reduced ? { opacity: 0 } : { clipPath: "inset(50% 0% 50% 0%)" }}
          animate={revealed ? (reduced ? { opacity: 1 } : { clipPath: "inset(0% 0% 0% 0%)" }) : undefined}
          transition={{ duration: 1.6, ease: EASE_LUXE }}
        >
          <div ref={photoRef} className="will-change-transform">
            <motion.picture
              className="block"
              initial={{ scale: reduced ? 1 : 1.12 }}
              animate={revealed ? { scale: 1 } : undefined}
              transition={{ duration: 9, ease: "easeOut" }}
            >
              <source srcSet={assets.collegePhoto.avif} type="image/avif" />
              <img
                src={assets.collegePhoto.fallback}
                alt={assets.collegePhoto.alt}
                width={assets.collegePhoto.width}
                height={assets.collegePhoto.height}
                fetchPriority="high"
                className="block aspect-[3/2] w-full object-cover"
              />
            </motion.picture>
          </div>
          {/* vignette as a separate overlay layer — photo itself untouched */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(120% 90% at 50% 40%, transparent 55%, color-mix(in oklab, var(--black-deep) 75%, transparent))" }} />
          <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 bottom-0 h-1/2" style={{ background: "linear-gradient(to top, var(--black-deep), transparent)" }} />
        </motion.div>
        <svg aria-hidden="true" className="pointer-events-none absolute -inset-2 h-[calc(100%+1rem)] w-[calc(100%+1rem)]" viewBox="0 0 100 70" preserveAspectRatio="none">
          {[0, 1.6].map((o, i) => (
            <motion.rect
              key={i}
              x={0.5 + o}
              y={0.5 + o}
              width={99 - o * 2}
              height={69 - o * 2}
              fill="none"
              stroke="var(--gold)"
              strokeWidth={0.35}
              vectorEffect="non-scaling-stroke"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={revealed ? { pathLength: 1, opacity: i === 0 ? 0.9 : 0.5 } : undefined}
              transition={{ duration: 2.2, delay: 0.4 + i * 0.25, ease: EASE_LUXE }}
            />
          ))}
        </svg>
        {/* corner ornaments */}
        {["-left-3 -top-3", "-right-3 -top-3 rotate-90", "-bottom-3 -right-3 rotate-180", "-bottom-3 -left-3 -rotate-90"].map((pos, i) => (
          <motion.svg
            key={i}
            aria-hidden="true"
            viewBox="0 0 24 24"
            className={`absolute h-6 w-6 text-gold ${pos}`}
            initial={{ opacity: 0 }}
            animate={revealed ? { opacity: 1 } : undefined}
            transition={{ delay: 1.6 + i * 0.1, duration: 0.8 }}
          >
            <path d="M2 12 V2 H12 M5 5 L9 9 M2 2 L6 6" fill="none" stroke="currentColor" strokeWidth="1.2" />
            <circle cx="12" cy="2" r="1.3" fill="currentColor" />
            <circle cx="2" cy="12" r="1.3" fill="currentColor" />
          </motion.svg>
        ))}
        {/* REVERIE title — rises through a mask with a light glint */}
        <div className="absolute inset-x-0 -bottom-7 text-center">
          <MaskReveal play={revealed} delay={reduced ? 0.2 : 0.8} duration={1.4}>
            <span className="relative inline-block">
              <span className="text-gold font-display text-[3.6rem] font-bold leading-none tracking-[0.14em] drop-shadow-[0_4px_18px_rgba(0,0,0,0.85)]">
                {invitation.title}
              </span>
              {!reduced && (
                <motion.span
                  aria-hidden="true"
                  className="absolute inset-y-0 w-1/3 -skew-x-12"
                  style={{ background: "linear-gradient(90deg, transparent, color-mix(in oklab, var(--ivory) 70%, transparent), transparent)", mixBlendMode: "overlay" }}
                  initial={{ left: "-40%", opacity: 0 }}
                  animate={revealed ? { left: "120%", opacity: [0, 1, 0] } : undefined}
                  transition={{ delay: 1.9, duration: 1.4, ease: EASE_LUXE }}
                />
              )}
            </span>
          </MaskReveal>
        </div>
      </div>

      <div className="mt-16 flex flex-col items-center text-center">
        <motion.img
          src={assets.collegeLogo.src}
          alt={assets.collegeLogo.alt}
          width={assets.collegeLogo.width}
          height={assets.collegeLogo.height}
          className="h-20 w-20 rounded-full border border-gold/60 bg-ivory object-contain p-1.5 shadow-[var(--glow-gold)]"
          initial={{ opacity: 0, scale: 0.85 }}
          animate={revealed ? { opacity: 1, scale: 1 } : undefined}
          transition={{ delay: base, duration: 1, ease: EASE_LUXE }}
        />
        <Ornament className="mt-5" />
        <div className="mt-5">
          {lines.map((l, i) => (
            <MaskReveal key={i} play={revealed} delay={base + 0.3 + i * 0.18} className={l.cls}>
              {l.node}
            </MaskReveal>
          ))}
        </div>
        <TypedTagline play={revealed} />
      </div>
    </SectionShell>
  );
}
