import { motion } from "framer-motion";
import { useInView } from "@/hooks/useInView";
import { CalendarDays, Clock, MapPin, PartyPopper, Users } from "lucide-react";
import { content, show, isPlaceholder } from "@/config/content";
import { SectionShell, Ornament } from "@/components/SectionReveal";
import { EASE_LUXE } from "@/animations/easing";

/** Glass detail card — rises in, icon stroke draws itself, sheen on press/hover. */
function EventCard({ icon: Icon, label, value, note, index }: { icon: typeof Clock; label: string; value: string; note?: string; index: number }) {
  const placeholder = value.startsWith("[");
  const [ref, inView] = useInView<HTMLLIElement>({ threshold: 0.4 });
  return (
    <motion.li
      ref={ref}
      className="glass-gold sheen group flex items-center gap-4 rounded-2xl px-5 py-4 transition-shadow duration-500 hover:shadow-[var(--glow-gold-strong)] active:shadow-[var(--glow-gold-strong)]"
      initial={{ opacity: 0, y: 36 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.4 }}
      transition={{ duration: 1, delay: index * 0.12, ease: EASE_LUXE }}
      tabIndex={0}
    >
      <span className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-gold/40">
        <motion.span
          className="flex"
          initial={{ opacity: 0, rotate: -20 }}
          whileInView={{ opacity: 1, rotate: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, delay: index * 0.12 + 0.3, ease: EASE_LUXE }}
        >
          <Icon
            className={`h-5 w-5 text-gold ${inView ? "icon-draw" : "icon-hidden"}`}
            style={{ animationDelay: `${index * 0.12 + 0.3}s` }}
            strokeWidth={1.4}
            aria-hidden="true"
          />
        </motion.span>
      </span>
      <div className="min-w-0">
        <p className="font-sans text-[0.62rem] uppercase tracking-[0.3em] text-gold-light/75">{label}</p>
        <p className={`font-display text-xl font-semibold leading-tight ${placeholder ? "text-destructive" : "text-ivory"}`}>{value}</p>
        {note && <p className="mt-0.5 font-sans text-xs text-muted-foreground">{note}</p>}
      </div>
    </motion.li>
  );
}

export function EventDetailsSection() {
  const e = content.event;
  const cards = [
    { icon: PartyPopper, label: "Event", value: show(e.name, "EVENT NAME"), note: show(e.session, "SESSION") },
    { icon: CalendarDays, label: "Date", value: show(e.date, "EVENT DATE"), note: isPlaceholder(e.dateNote) ? undefined : e.dateNote },
    { icon: Clock, label: "Time", value: show(e.time, "EVENT TIME"), note: show(e.session, "SESSION") },
    { icon: MapPin, label: "Venue", value: show(e.venue, "EVENT VENUE") },
    { icon: Users, label: "Organized By", value: show(e.organizedBy, "DEPARTMENT / FORUM NAME") },
  ];
  return (
    <SectionShell id="details" label="Event details">
      <motion.p
        className="font-sans text-[0.7rem] uppercase tracking-[0.4em] text-gold-light/80"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
      >
        Save the Date
      </motion.p>
      <motion.h2
        className="text-gold mt-3 text-center font-display text-4xl font-semibold"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.1, ease: EASE_LUXE }}
      >
        The Celebration
      </motion.h2>
      <Ornament className="mt-5" />
      <ul className="mt-10 flex w-full flex-col gap-4">
        {cards.map((c, i) => (
          <EventCard key={c.label} index={i} {...c} />
        ))}
      </ul>
    </SectionShell>
  );
}
