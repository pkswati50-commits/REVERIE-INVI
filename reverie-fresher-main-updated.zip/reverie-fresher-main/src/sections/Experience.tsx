import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, ArrowRight, Check, Loader as Loader2, Pencil } from "lucide-react";
import { content } from "@/config/content";
import { SectionShell, Ornament } from "@/components/SectionReveal";
import { FormStep } from "@/components/FormStep";
import { QuestionCard } from "@/components/QuestionCard";
import { GoldButton } from "@/components/GoldButton";
import { WordReveal } from "@/components/TextReveal";
import { EASE_LUXE } from "@/animations/easing";
import { branchSchema, nameSchema, type RsvpResult } from "@/lib/rsvp-schema";
import { confirmPresence } from "@/lib/rsvp.functions";
import { chime } from "@/lib/sound";

export type FresherData = { fullName: string; branch: string; answers: string[] };

const FIELDS = [
  { key: "fullName", label: "Full Name", schema: nameSchema, placeholder: "e.g. Ananya Shetty", autoComplete: "name", autoCapitalize: "words", max: 80 },
  { key: "branch", label: "Branch / Department", schema: branchSchema, placeholder: "e.g. CSE (Data Science)", autoComplete: "off", autoCapitalize: "words", max: 80 },
] as const;

const Q = content.experience.questions;
const STEP_MESSAGE = FIELDS.length + Q.length;
const STEP_DONE = STEP_MESSAGE + 1;

type SubmitState = { phase: "idle" } | { phase: "loading" } | { phase: "success"; result: RsvpResult } | { phase: "error"; message: string };

export function ExperienceSection({ data, setData }: { data: FresherData; setData: (d: FresherData) => void }) {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [error, setError] = useState<string | undefined>();
  const [shake, setShake] = useState(0);
  const [submit, setSubmit] = useState<SubmitState>({ phase: "idle" });
  const send = useServerFn(confirmPresence);

  const go = (to: number) => {
    setDir(to > step ? 1 : -1);
    setError(undefined);
    setStep(to);
  };

  const validateField = (i: number) => {
    const f = FIELDS[i];
    const res = f.schema.safeParse(data[f.key]);
    if (!res.success) {
      setError(res.error.issues[0]?.message ?? "Please check this field");
      setShake((s) => s + 1);
      return false;
    }
    return true;
  };

  const next = () => {
    if (step < FIELDS.length) {
      if (!validateField(step)) return;
      chime(0.4);
    }
    if (step >= FIELDS.length && step < STEP_MESSAGE && !data.answers[step - FIELDS.length]) {
      setError("Please choose an answer");
      setShake((s) => s + 1);
      return;
    }
    go(step + 1);
  };

  const answer = (qi: number, v: string) => {
    const answers = [...data.answers];
    answers[qi] = v;
    setData({ ...data, answers });
    setError(undefined);
    setTimeout(() => go(FIELDS.length + qi + 1), 750);
  };

  const confirm = async () => {
    // re-validate everything before submitting
    for (let i = 0; i < FIELDS.length; i++) {
      const r = FIELDS[i].schema.safeParse(data[FIELDS[i].key]);
      if (!r.success) { go(i); setError(r.error.issues[0]?.message); return; }
    }
    if (data.answers.filter(Boolean).length < Q.length) { go(FIELDS.length + data.answers.filter(Boolean).length); return; }
    setSubmit({ phase: "loading" });
    try {
      const result = await send({ data: { fullName: data.fullName, branch: data.branch, answers: data.answers } });
      if (result.status === "error") {
        setSubmit({ phase: "error", message: result.message });
        return;
      }
      setSubmit({ phase: "success", result });
      chime(1);
      setTimeout(() => go(STEP_DONE), 1300);
    } catch {
      setSubmit({ phase: "error", message: "Something went wrong while confirming. Please check your connection and try again." });
    }
  };

  const edit = () => {
    setSubmit({ phase: "idle" });
    go(0);
  };

  const progress = Math.min(step, STEP_MESSAGE) / STEP_MESSAGE;
  const firstName = data.fullName.trim() || "JUNIOR";

  return (
    <SectionShell id="experience" label="Fresher experience">
      <motion.h2
        className="text-gold text-center font-display text-[2rem] font-semibold leading-tight"
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.1, ease: EASE_LUXE }}
      >
        {content.experience.heading}
      </motion.h2>
      <p className="mt-2 text-center font-display text-lg italic text-ivory/85">{content.experience.subtitle}</p>
      <Ornament className="mt-5" />

      {/* gold progress bar */}
      <div className="mt-8 h-[3px] w-full overflow-hidden rounded-full bg-gold/15" role="progressbar" aria-label="Invitation progress" aria-valuenow={Math.round(progress * 100)} aria-valuemin={0} aria-valuemax={100}>
        <motion.div className="h-full origin-left rounded-full" style={{ background: "var(--gradient-gold-soft)" }} animate={{ scaleX: progress }} initial={{ scaleX: 0 }} transition={{ duration: 0.8, ease: EASE_LUXE }} />
      </div>

      <div className="relative mt-8 min-h-[340px] w-full">
        <AnimatePresence mode="wait" custom={dir} initial={false}>
          <motion.div
            key={step}
            custom={dir}
            initial={{ opacity: 0, x: dir * 60 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: dir * -60 }}
            transition={{ duration: 0.6, ease: EASE_LUXE }}
            className="w-full"
          >
            {step < FIELDS.length && (
              <div className="flex flex-col items-center gap-4">
                <p className="font-mono text-[0.7rem] text-gold/70">step {step + 1} / {FIELDS.length}</p>
                <FormStep
                  label={FIELDS[step].label}
                  value={data[FIELDS[step].key]}
                  onChange={(v) => { setData({ ...data, [FIELDS[step].key]: v }); if (error) setError(undefined); }}
                  error={error}
                  shake={shake}
                  placeholder={FIELDS[step].placeholder}
                  autoComplete={FIELDS[step].autoComplete}
                  autoCapitalize={FIELDS[step].autoCapitalize}
                  maxLength={FIELDS[step].max}
                  onEnter={next}
                />
                <div className="mt-2 flex w-full items-center justify-between">
                  <button
                    type="button"
                    onClick={() => go(step - 1)}
                    disabled={step === 0}
                    className="flex items-center gap-1 font-sans text-xs uppercase tracking-[0.2em] text-gold-light/80 transition-opacity disabled:opacity-0"
                  >
                    <ArrowLeft className="h-4 w-4" /> Back
                  </button>
                  <GoldButton onClick={next} aria-label="Next step">
                    Next <ArrowRight className="h-4 w-4" />
                  </GoldButton>
                </div>
              </div>
            )}

            {step >= FIELDS.length && step < STEP_MESSAGE && (
              <div className="flex flex-col items-center">
                <QuestionCard
                  index={step - FIELDS.length}
                  total={Q.length}
                  question={Q[step - FIELDS.length].q}
                  options={Q[step - FIELDS.length].options}
                  selected={data.answers[step - FIELDS.length]}
                  onSelect={(v) => answer(step - FIELDS.length, v)}
                />
                <p role="alert" aria-live="polite" className="mt-3 min-h-5 font-sans text-xs text-destructive">{error ?? ""}</p>
                <button type="button" onClick={() => go(step - 1)} className="mt-2 flex items-center gap-1 font-sans text-xs uppercase tracking-[0.2em] text-gold-light/80">
                  <ArrowLeft className="h-4 w-4" /> Back
                </button>
              </div>
            )}

            {step === STEP_MESSAGE && (
              <div className="flex flex-col items-center text-center">
                <p className="font-display text-[1.9rem] font-semibold leading-snug text-ivory">
                  <WordReveal text="Dear" />
                  <WordReveal text={`${firstName},`} delay={0.15} className="text-gold" />
                </p>
                <p className="mt-3 font-display text-xl italic text-ivory/90">
                  <WordReveal text={content.experience.personalLine} delay={0.5} stagger={0.12} highlight={["Fresher", "party"]} />
                </p>
                <div className="relative mt-10 flex h-16 items-center justify-center">
                  <AnimatePresence mode="wait">
                    {submit.phase === "success" ? (
                      <motion.div
                        key="ok"
                        className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gold text-black-deep shadow-[var(--glow-gold-strong)]"
                        initial={{ scale: 0.4, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        transition={{ duration: 0.6, ease: EASE_LUXE }}
                      >
                        <Check className="h-8 w-8" strokeWidth={2.6} />
                        {Array.from({ length: 10 }).map((_, i) => (
                          <motion.span
                            key={i}
                            aria-hidden="true"
                            className="absolute h-1.5 w-1.5 rounded-full bg-gold-light"
                            initial={{ x: 0, y: 0, opacity: 1 }}
                            animate={{ x: Math.cos((i / 10) * Math.PI * 2) * 56, y: Math.sin((i / 10) * Math.PI * 2) * 56, opacity: 0 }}
                            transition={{ duration: 1, ease: EASE_LUXE }}
                          />
                        ))}
                      </motion.div>
                    ) : (
                      <motion.div key="btn" exit={{ scale: 0.6, opacity: 0 }} transition={{ duration: 0.35 }}>
                        <GoldButton size="lg" solid onClick={confirm} disabled={submit.phase === "loading"} aria-busy={submit.phase === "loading"}>
                          {submit.phase === "loading" ? (<><Loader2 className="h-4 w-4 animate-spin" /> Confirming…</>) : content.experience.confirmButton}
                        </GoldButton>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <p role="status" aria-live="polite" className="mt-4 min-h-5 max-w-xs font-sans text-xs text-destructive">
                  {submit.phase === "error" ? submit.message : ""}
                </p>
                <button type="button" onClick={edit} className="mt-1 flex items-center gap-1 font-sans text-xs uppercase tracking-[0.2em] text-gold-light/80">
                  <Pencil className="h-3.5 w-3.5" /> Edit my answers
                </button>
              </div>
            )}

            {step === STEP_DONE && (
              <div className="glass-gold flex flex-col items-center rounded-2xl px-6 py-8 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-gold text-black-deep shadow-[var(--glow-gold-strong)]">
                  <Check className="h-7 w-7" strokeWidth={2.6} />
                </span>
                <h3 className="mt-5 font-display text-2xl font-semibold text-ivory">
                  {submit.phase === "success" && submit.result.status === "saved" ? "Your presence is confirmed!" : "Thank you for confirming!"}
                </h3>
                <p className="mt-1 font-display text-lg italic text-gold-light">{data.fullName}</p>
                <p role="status" aria-live="polite" className="mt-4 font-sans text-sm leading-relaxed text-ivory/80">
                  {submit.phase === "success" && submit.result.status === "saved"
                    ? "Your response has been saved. We can't wait to celebrate with you!"
                    : "Note: your response was NOT stored — the registration server isn't set up yet. Please confirm with your seniors in person."}
                </p>
                <ul className="mt-5 w-full space-y-1.5 text-left font-sans text-xs text-ivory/70">
                  <li><span className="text-gold-light/80">Branch:</span> {data.branch}</li>
                  {Q.map((q, i) => (
                    <li key={i}><span className="text-gold-light/80">Q{i + 1}:</span> {data.answers[i]}</li>
                  ))}
                </ul>
                <div className="mt-6">
                  <GoldButton size="sm" onClick={edit}>
                    <Pencil className="h-3.5 w-3.5" /> Edit my answers
                  </GoldButton>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </SectionShell>
  );
}
