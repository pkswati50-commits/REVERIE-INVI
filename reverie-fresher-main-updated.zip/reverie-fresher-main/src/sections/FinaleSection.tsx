import { motion } from "framer-motion";
import { RotateCcw } from "lucide-react";
import { content } from "@/config/content";
import { Particles } from "@/components/Particles";
import { GoldButton } from "@/components/GoldButton";
import { SunriseRays } from "@/components/FloatingLights";
import { EASE_LUXE } from "@/animations/easing";
import { useInView } from "@/hooks/useInView";

export function FinaleSection({ name, onReplay }: { name: string; onReplay: () => void }) {
  const [ref, inView] = useInView<HTMLElement>({ threshold: 0.45 });
  const f = content.finale;
  return (
    <section
      ref={ref}
      id="finale"
      data-section="finale"
      aria-label="Grand finale"
      className="relative flex min-h-stage w-full flex-col items-center justify-center overflow-hidden px-6 pb-[calc(var(--safe-bottom)+4rem)] pt-20 text-center"
    >
      <div aria-hidden="true" className="absolute inset-0" style={{ background: "radial-gradient(90% 70% at 50% 45%, color-mix(in oklab, var(--gold-deep) 35%, var(--black-deep)), var(--black-deep) 75%)" }} />
      <div
        aria-hidden="true"
        className="anim-rays absolute left-1/2 top-1/2 aspect-square w-[260%] -translate-x-1/2 -translate-y-1/2 opacity-30"
        style={{
          background: "repeating-conic-gradient(from 0deg, color-mix(in oklab, var(--gold-light) 50%, transparent) 0deg 4deg, transparent 4deg 20deg)",
          WebkitMask: "radial-gradient(circle, #000 5%, transparent 50%)",
          mask: "radial-gradient(circle, #000 5%, transparent 50%)",
        }}
      />
      <SunriseRays strength={0.6} />
      <Particles mode="confetti" count={250} fire={inView} />

      <motion.h2
        className="text-gold-loop relative font-display text-[2.6rem] font-bold leading-[1.05]"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={inView ? { opacity: 1, scale: 1 } : undefined}
        transition={{ duration: 1.6, ease: EASE_LUXE }}
        style={{ textShadow: "0 0 40px color-mix(in oklab, var(--gold) 45%, transparent)" }}
      >
        {f.title}
      </motion.h2>
      <motion.p
        className="relative mt-5 max-w-xs font-display text-lg italic text-ivory/90"
        initial={{ opacity: 0, y: 12 }}
        animate={inView ? { opacity: 1, y: 0 } : undefined}
        transition={{ duration: 1.2, delay: 0.8, ease: EASE_LUXE }}
      >
        {f.line}
      </motion.p>
      <motion.div
        className="relative mt-10"
        initial={{ opacity: 0, y: 16 }}
        animate={inView ? { opacity: 1, y: 0 } : undefined}
        transition={{ duration: 1.2, delay: 1.6, ease: EASE_LUXE }}
      >
        <p className="font-sans text-sm font-semibold uppercase tracking-[0.35em] text-ivory">{f.seeYou}</p>
        {name.trim() && <p className="text-gold mt-2 font-display text-3xl font-semibold">{name.trim()}</p>}
      </motion.div>
      <motion.div
        className="relative mt-12"
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : undefined}
        transition={{ duration: 1, delay: 2.4 }}
      >
        <GoldButton size="lg" onClick={onReplay}>
          <RotateCcw className="h-4 w-4" /> {f.replay}
        </GoldButton>
      </motion.div>
    </section>
  );
}
