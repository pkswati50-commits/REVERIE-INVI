import { motion } from "framer-motion";
import { content } from "@/config/content";
import { WordReveal } from "@/components/TextReveal";
import { EASE_LUXE } from "@/animations/easing";
import { useInView } from "@/hooks/useInView";

const GLOWS = [
  "radial-gradient(70% 50% at 20% 30%, color-mix(in oklab, var(--gold) 22%, transparent), transparent 70%)",
  "radial-gradient(70% 50% at 80% 50%, color-mix(in oklab, var(--amber) 20%, transparent), transparent 70%)",
  "radial-gradient(80% 55% at 50% 75%, color-mix(in oklab, var(--gold-light) 18%, transparent), transparent 70%)",
];

function MessageBeat({ text, highlight, index, last }: { text: string; highlight: string[]; index: number; last: boolean }) {
  const [ref, inView] = useInView<HTMLDivElement>({ threshold: 0.35 });
  return (
    <div ref={ref} className="relative flex min-h-stage w-full flex-col items-center justify-center px-7 py-16 text-center">
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{ background: GLOWS[index % GLOWS.length] }}
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : { opacity: 0 }}
        transition={{ duration: 1.6 }}
      />
      <span className="relative font-mono text-[0.7rem] text-gold/60">0{index + 1}</span>
      <p className="relative mt-5 font-display text-[1.45rem] leading-relaxed text-ivory">
        <WordReveal text={text} highlight={highlight} play={inView} stagger={0.045} />
      </p>
      {!last && (
        <motion.span
          aria-hidden="true"
          className="gold-rule absolute bottom-6 left-1/2 block w-40 -translate-x-1/2 origin-center"
          initial={{ scaleX: 0 }}
          animate={inView ? { scaleX: 1 } : undefined}
          transition={{ duration: 1.6, delay: 1, ease: EASE_LUXE }}
        />
      )}
    </div>
  );
}

export function MessagesSection() {
  const msgs = content.specialMessages;
  return (
    <section id="messages" data-section="messages" aria-label="Special messages" className="relative w-full">
      <div className="flex min-h-[45svh] flex-col items-center justify-end px-6 pb-4 pt-24 text-center">
        <motion.h2
          className="text-gold font-display text-[2rem] font-semibold leading-tight"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.1, ease: EASE_LUXE }}
        >
          {content.messagesHeading}
        </motion.h2>
      </div>
      {msgs.map((m, i) => (
        <MessageBeat key={i} index={i} text={m.text} highlight={m.highlight} last={i === msgs.length - 1} />
      ))}
    </section>
  );
}
