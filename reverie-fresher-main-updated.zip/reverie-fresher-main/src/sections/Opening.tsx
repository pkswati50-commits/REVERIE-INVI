import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import gsap from "gsap";
import { content } from "@/config/content";
import { Envelope, type EnvelopeHandle } from "@/components/Envelope";
import { Curtains, type CurtainsHandle } from "@/components/Curtains";
import { Particles } from "@/components/Particles";
import { FloatingLights } from "@/components/FloatingLights";
import { GoldButton } from "@/components/GoldButton";
import { LetterReveal } from "@/components/TextReveal";
import { EASE_LUXE } from "@/animations/easing";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { chime } from "@/lib/sound";

type Stage = "intro" | "envelope" | "opening";

/** Preloads hero assets, reporting progress 0..1. */
function usePreload(urls: string[]) {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    let done = 0;
    let cancelled = false;
    urls.forEach((u) => {
      const img = new Image();
      const finish = () => {
        done += 1;
        if (!cancelled) setProgress(done / urls.length);
      };
      img.onload = finish;
      img.onerror = finish;
      img.src = u;
    });
    return () => { cancelled = true; };
  }, [urls]);
  return progress;
}

const PRELOAD = [content.assets.collegePhoto.fallback, content.assets.collegeLogo.src];

export function OpeningSequence({ onReveal, onDone }: { onReveal: () => void; onDone: () => void }) {
  const reduced = useReducedMotion();
  const [stage, setStage] = useState<Stage>("intro");
  const progress = usePreload(PRELOAD);
  const [introDone, setIntroDone] = useState(false);
  const intensity = useRef(1);
  const envRef = useRef<EnvelopeHandle>(null);
  const curtainsRef = useRef<CurtainsHandle>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const baseRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const riseRef = useRef<HTMLDivElement>(null);
  const wipeRef = useRef<HTMLDivElement>(null);
  const stageGlowRef = useRef<HTMLDivElement>(null);
  const tlRef = useRef<gsap.core.Timeline | null>(null);
  const finished = useRef(false);
  const revealed = useRef(false);

  const reveal = useCallback(() => {
    if (revealed.current) return;
    revealed.current = true;
    onReveal();
  }, [onReveal]);
  const finish = useCallback(() => {
    if (finished.current) return;
    finished.current = true;
    reveal();
    onDone();
  }, [onDone, reveal]);

  // Scene 1 timing: ~6s, waits for preload (max 9s)
  useEffect(() => {
    const t = setTimeout(() => setIntroDone(true), reduced ? 2200 : 6200);
    const failSafe = setTimeout(() => setStage((s) => (s === "intro" ? "envelope" : s)), 9500);
    return () => { clearTimeout(t); clearTimeout(failSafe); };
  }, [reduced]);
  useEffect(() => {
    if (stage === "intro" && introDone && progress >= 1) setStage("envelope");
  }, [stage, introDone, progress]);

  // Envelope rise + tilt (drag / device orientation, max 6deg)
  useEffect(() => {
    if (stage !== "envelope") return;
    const rise = riseRef.current;
    const tilt = envRef.current?.tilt;
    if (!rise || !tilt) return;
    const ctx = gsap.context(() => {
      gsap.fromTo(rise, { y: reduced ? 0 : 220, opacity: 0 }, { y: 0, opacity: 1, duration: reduced ? 0.5 : 1.8, ease: "expo.out" });
      if (ctaRef.current) gsap.fromTo(ctaRef.current, { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 1.2, delay: reduced ? 0.2 : 1.1, ease: "expo.out" });
    });
    if (reduced) return () => ctx.revert();
    const rx = gsap.quickTo(tilt, "rotationX", { duration: 0.8, ease: "power3.out" });
    const ry = gsap.quickTo(tilt, "rotationY", { duration: 0.8, ease: "power3.out" });
    const root = rootRef.current!;
    const onMove = (e: PointerEvent) => {
      const r = root.getBoundingClientRect();
      const nx = (e.clientX - r.left) / r.width - 0.5;
      const ny = (e.clientY - r.top) / r.height - 0.5;
      ry(nx * 12);
      rx(-ny * 12);
    };
    const onLeave = () => { rx(0); ry(0); };
    const onOrient = (e: DeviceOrientationEvent) => {
      if (e.beta == null || e.gamma == null) return;
      ry(Math.max(-6, Math.min(6, e.gamma / 5)));
      rx(Math.max(-6, Math.min(6, (e.beta - 45) / 6)));
    };
    root.addEventListener("pointermove", onMove);
    root.addEventListener("pointerleave", onLeave);
    window.addEventListener("deviceorientation", onOrient);
    return () => {
      root.removeEventListener("pointermove", onMove);
      root.removeEventListener("pointerleave", onLeave);
      window.removeEventListener("deviceorientation", onOrient);
      ctx.revert();
    };
  }, [stage, reduced]);

  const open = () => {
    if (stage !== "envelope") return;
    setStage("opening");
    chime(1);
    const env = envRef.current!;
    const cur = curtainsRef.current!;
    if (reduced) {
      const tl = gsap.timeline({ onComplete: finish });
      tl.to(rootRef.current, { opacity: 0, duration: 0.6, ease: "power1.out", onStart: reveal });
      tlRef.current = tl;
      return;
    }
    gsap.set(env.tilt, { rotationX: 0, rotationY: 0 });
    const tl = gsap.timeline({ onComplete: finish, defaults: { ease: "expo.out" } });
    tlRef.current = tl;
    // 1. fade CTA + dim
    tl.to(ctaRef.current, { opacity: 0, y: 10, duration: 0.5 }, 0);
    tl.to(stageGlowRef.current, { opacity: 0.25, duration: 0.6 }, 0);
    // 2. wax seal cracks + 10 flecks
    tl.to(env.sealL, { x: -22, rotation: -28, opacity: 0, duration: 0.9 }, 0.2);
    tl.to(env.sealR, { x: 22, rotation: 28, opacity: 0, duration: 0.9 }, 0.2);
    env.flecks.forEach((f, i) => {
      const a = (i / 10) * Math.PI * 2 + Math.random() * 0.4;
      const d = 40 + Math.random() * 40;
      tl.fromTo(f, { opacity: 1, x: 0, y: 0, rotation: 0 }, { opacity: 0, x: Math.cos(a) * d, y: Math.sin(a) * d, rotation: 180, duration: 1, ease: "power3.out" }, 0.22);
    });
    // 3. flap opens with a slight overshoot
    tl.to(env.flap, { rotationX: -180, duration: 1.0, ease: "back.out(1.15)" }, 0.8);
    tl.set(env.flap, { zIndex: 3 }, 1.15);
    // 4. warm light pours out + lens flare
    tl.fromTo(env.glow, { opacity: 0, scale: 0.2 }, { opacity: 1, scale: 1, duration: 1.4 }, 1.6);
    tl.fromTo(env.flare, { opacity: 0, scaleX: 0 }, { opacity: 1, scaleX: 1, duration: 0.8 }, 1.7);
    tl.to(env.flare, { opacity: 0, duration: 0.8 }, 2.5);
    // 5. card slides up and settles
    tl.to(env.card, { yPercent: -62, duration: 1.0, ease: "expo.out" }, 2.0);
    // 6. card flies toward camera; envelope drops away
    tl.set(env.card, { zIndex: 20 }, 2.95);
    tl.to(env.card, { yPercent: -20, scale: 5, opacity: 0, duration: 1.1, ease: "power3.in" }, 3.0);
    tl.to(env.shell, { y: 240, opacity: 0, duration: 1.0, ease: "power3.in" }, 3.0);
    tl.to(env.glow, { opacity: 0, duration: 0.8 }, 3.2);
    // 7. curtains: appear closed, then part with a seam flare; sparkles peak
    tl.to(cur.root, { opacity: 1, duration: 0.5, ease: "power1.out" }, 3.25);
    tl.fromTo(cur.seam, { opacity: 0 }, { opacity: 1, duration: 0.5 }, 3.5);
    tl.to(intensity, { current: 2.6, duration: 0.6, ease: "power2.out" }, 3.7);
    tl.to(stageGlowRef.current, { opacity: 1, duration: 0.8 }, 3.8);
    tl.to(cur.left, { xPercent: -105, duration: 2.2, ease: "expo.inOut" }, 3.8);
    tl.to(cur.right, { xPercent: 105, duration: 2.2, ease: "expo.inOut" }, 3.8);
    tl.to(cur.seam, { opacity: 0, scaleX: 4, duration: 1.2 }, 4.3);
    tl.to(intensity, { current: 1, duration: 1.5 }, 5.2);
    // 8. diagonal golden light wipe → reveal content
    tl.fromTo(wipeRef.current, { xPercent: -100, opacity: 1 }, { xPercent: 100, duration: 1.2, ease: "power3.inOut" }, 5.0);
    tl.set([baseRef.current, stageGlowRef.current, cur.root], { opacity: 0 }, 5.6);
    tl.call(reveal, [], 5.6);
    tl.to({}, { duration: 0.1 }, 6.2);
  };

  // Clean up any running timeline on unmount (replay / skip)
  useEffect(() => () => { tlRef.current?.kill(); }, []);

  const skip = () => {
    tlRef.current?.kill();
    finish();
  };

  return (
    <div ref={rootRef} className="absolute inset-0 z-50 overflow-hidden" role="dialog" aria-label="Invitation opening" aria-modal="true">
      <div ref={baseRef} className="absolute inset-0 bg-black-deep" />
      {/* breathing radial glow */}
      <div ref={stageGlowRef} aria-hidden="true" className="absolute inset-0">
        <motion.div
          className="anim-glow-breathe absolute left-1/2 top-1/2 h-[120%] w-[160%] -translate-x-1/2 -translate-y-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: reduced ? 0 : 2, duration: 2 }}
          style={{ background: "radial-gradient(circle at center, color-mix(in oklab, var(--gold) 28%, transparent), transparent 55%)" }}
        />
      </div>
      <motion.div className="absolute inset-0" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8, duration: 1.6 }}>
        <Particles mode="sparkle" count={60} intensityRef={intensity} />
      </motion.div>

      <AnimatePresence mode="wait">
        {stage === "intro" && (
          <motion.div
            key="intro"
            className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center"
            exit={{ opacity: 0, scale: 1.04, filter: "blur(6px)" }}
            transition={{ duration: 1, ease: EASE_LUXE }}
          >
            {/* thin gold loading line */}
            <div className="absolute left-1/2 top-[calc(var(--safe-top)+2.5rem)] h-px w-32 -translate-x-1/2 bg-gold/15" role="progressbar" aria-label="Loading invitation" aria-valuenow={Math.round(progress * 100)} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-full origin-left bg-gold transition-transform duration-700" style={{ transform: `scaleX(${progress})` }} />
            </div>
            <h1 className="text-gold-shimmer font-display text-[1.65rem] font-semibold leading-tight sm:text-3xl" style={{ animationDelay: reduced ? "0s" : "3.6s" }}>
              <LetterReveal text={content.invitation.introTitle} delay={reduced ? 0.1 : 2.5} stagger={reduced ? 0 : 0.05} />
            </h1>
            <motion.p
              className="mt-5 font-display text-lg italic text-ivory/85"
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: reduced ? 0.6 : 4, duration: 1.4, ease: EASE_LUXE }}
            >
              {content.invitation.introSubtitle}
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>

      {stage !== "intro" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-14 px-6">
          <FloatingLights className="opacity-70" />
          <div ref={riseRef} className="relative opacity-0">
            {/* orbiting lights */}
            <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 h-[150%] w-[130%] -translate-x-1/2 -translate-y-1/2">
              <div className="absolute inset-0" style={{ animation: "rays-rotate 16s linear infinite" }}>
                <span className="absolute left-0 top-1/2 h-3 w-3 rounded-full bg-gold-light/80 blur-[2px]" />
                <span className="absolute right-0 top-1/3 h-2 w-2 rounded-full bg-gold/80 blur-[1px]" />
              </div>
              <div className="absolute inset-[12%]" style={{ animation: "rays-rotate 24s linear infinite reverse" }}>
                <span className="absolute bottom-0 left-1/2 h-2.5 w-2.5 rounded-full bg-gold-light/70 blur-[2px]" />
              </div>
            </div>
            <div className={reduced ? "" : "anim-levitate"}>
              <Envelope ref={envRef} />
            </div>
          </div>
          <div ref={ctaRef} className="flex flex-col items-center gap-4 opacity-0">
            <p className="font-display text-base italic text-ivory/75">Sealed with gold, just for you</p>
            <GoldButton size="lg" onClick={open} disabled={stage !== "envelope"} aria-label="Open your invitation">
              {content.invitation.openButton}
            </GoldButton>
          </div>
        </div>
      )}

      <Curtains ref={curtainsRef} />
      {/* diagonal golden light wipe */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[45] overflow-hidden">
        <div
          ref={wipeRef}
          className="absolute -inset-y-[20%] left-[-75%] w-[250%] opacity-0"
          style={{
            transform: "translateX(-100%)",
            background:
              "linear-gradient(115deg, transparent 0%, color-mix(in oklab, var(--gold) 70%, transparent) 30%, var(--gold-light) 44%, var(--ivory) 50%, var(--gold-light) 56%, color-mix(in oklab, var(--gold) 70%, transparent) 70%, transparent 100%)",
          }}
        />
      </div>

      <button
        type="button"
        onClick={skip}
        className="absolute right-4 top-[calc(var(--safe-top)+1rem)] z-[60] rounded-full border border-gold/40 bg-black-deep/60 px-3 py-1.5 font-sans text-[0.65rem] uppercase tracking-[0.25em] text-gold-light/90 transition-colors hover:border-gold hover:text-ivory"
      >
        Skip
      </button>
    </div>
  );
}
