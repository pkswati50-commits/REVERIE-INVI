import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import gsap from "gsap";
import { Expand } from "lucide-react";
import { content } from "@/config/content";
import { SectionShell } from "@/components/SectionReveal";
import { PosterViewer } from "@/components/PosterViewer";
import { Particles } from "@/components/Particles";
import { EASE_LUXE } from "@/animations/easing";
import { useInView } from "@/hooks/useInView";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { chime, haptic } from "@/lib/sound";

export function PosterSection() {
  const { poster } = content.assets;
  const [open, setOpen] = useState(false);
  const [frameRef, inView] = useInView<HTMLDivElement>({ threshold: 0.3 });
  const darkRef = useRef<HTMLDivElement>(null);
  const sweepRef = useRef<HTMLDivElement>(null);
  const zoomRef = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();

  const sweep = () => {
    if (reduced || !sweepRef.current) return;
    gsap.fromTo(sweepRef.current, { xPercent: -160, opacity: 1 }, { xPercent: 260, duration: 1.4, ease: "power3.inOut" });
  };

  // emerge from darkness (overlay fades — poster pixels never filtered) + slow zoom + sweep
  useEffect(() => {
    if (!inView) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.to(darkRef.current, { opacity: 0, duration: 0.4 });
        return;
      }
      gsap.fromTo(darkRef.current, { opacity: 1 }, { opacity: 0, duration: 2, ease: "power2.out" });
      gsap.fromTo(zoomRef.current, { scale: 0.94 }, { scale: 1, duration: 2.4, ease: "expo.out" });
      gsap.delayedCall(1.2, sweep);
    });
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView, reduced]);

  return (
    <SectionShell id="poster" label="Official poster">
      <motion.h2
        className="text-gold text-center font-display text-[2rem] font-semibold leading-tight"
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.1, ease: EASE_LUXE }}
      >
        {content.posterHeading}
      </motion.h2>

      <div ref={frameRef} className="relative mt-10 w-full">
        <div ref={zoomRef}>
          {!open && (
            <motion.button
              layoutId="poster"
              type="button"
              onClick={() => { haptic(); chime(0.6); sweep(); setTimeout(() => setOpen(true), reduced ? 0 : 350); }}
              aria-label="Open the official poster full screen"
              className="ornate-frame group relative block w-full overflow-hidden rounded-md"
              transition={{ duration: 0.6, ease: EASE_LUXE }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={poster.src}
                  alt={poster.alt}
                  width={poster.width}
                  height={poster.height}
                  loading="lazy"
                  decoding="async"
                  className="block h-auto w-full object-contain"
                />
                {/* darkness overlay (separate layer) */}
                <div ref={darkRef} aria-hidden="true" className="pointer-events-none absolute inset-0 bg-black-deep" />
                {/* diagonal light sweep */}
                <div
                  ref={sweepRef}
                  aria-hidden="true"
                  className="pointer-events-none absolute -inset-y-[10%] left-0 w-1/2 -skew-x-12 opacity-0"
                  style={{ background: "linear-gradient(100deg, transparent, color-mix(in oklab, var(--gold-light) 40%, transparent), transparent)" }}
                />
                {/* sparkles ABOVE the poster on their own layer */}
                <Particles mode="sparkle" count={18} />
              </div>
              <span className="absolute bottom-4 right-4 flex items-center gap-1.5 rounded-full border border-gold/60 bg-black-deep/70 px-3 py-1.5 font-sans text-[0.6rem] uppercase tracking-[0.2em] text-gold-light">
                <Expand className="h-3 w-3" /> Tap to view
              </span>
            </motion.button>
          )}
          {open && <div className="ornate-frame w-full rounded-md" style={{ aspectRatio: `${poster.width} / ${poster.height}` }} />}
        </div>
      </div>

      <AnimatePresence>{open && <PosterViewer onClose={() => setOpen(false)} />}</AnimatePresence>
    </SectionShell>
  );
}
